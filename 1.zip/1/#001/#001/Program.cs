﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _001
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Escriba una función que reciba una cantidad entera de segundos y retorne un string que muestre esa cantidad en formato HH:MM:SS. NO utilizar la clase DateTime.


            Console.Write("Ingrese la cantidad de segundos: ");
            int segundos = int.Parse(Console.ReadLine());

            string tiempo = ConvertirASegundos(segundos);

            Console.WriteLine("Formato HH:MM:SS " + tiempo);

            Console.ReadKey();
        }

        static string ConvertirASegundos(int totalSegundos)
        {
            int horas = totalSegundos / 3600;
            int minutos = (totalSegundos % 3600) / 60;
            int segundos = totalSegundos % 60;

            return horas.ToString("00") + ":" +
                   minutos.ToString("00") + ":" +
                   segundos.ToString("00");















        }
    }
}
