﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //  - Escriba una función que imprima únicamente los números primos de la serie de Fibonacci hasta el n-ésimo término.


            Console.Write("Ingrese cuántos términos de Fibonacci desea: ");
            int n = int.Parse(Console.ReadLine());

            MostrarFibonacciPrimos(n);

            Console.ReadKey();
        }

        static void MostrarFibonacciPrimos(int n)
        {
            int a = 0;
            int b = 1;

            for (int i = 1; i <= n; i++)
            {
                int fibonacci = a;

                if (EsPrimo(fibonacci))
                {
                    Console.WriteLine(fibonacci);
                }

                int temp = a + b;
                a = b;
                b = temp;
            }
        }

        static bool EsPrimo(int numero)
        {
            if (numero < 2)
                return false;

            for (int i = 2; i <= numero / 2; i++)
            {
                if (numero % i == 0)
                    return false;
            }

            return true;
        }





    }
    }

