﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Genérico compra un chance en el cual se juega eligiendo un número de 4 dígitos,
            // que se compara con el número resultado del sorteo semanal de los viernes. Genérico apuesta $1000 a un número num,
            // esperando que sea igual al número resultado que se conocerá el viernes.

            Console.Write("Ingrese el número de 4 dígitos para apostar: ");
            int num = int.Parse(Console.ReadLine());

            int apuesta = 1000;

            int numeroSorteo = GenerarNumeroSorteo();

            Console.WriteLine("Número del sorteo: " + numeroSorteo);

            if (num == numeroSorteo)
            {
                Console.WriteLine("¡Felicidades! Ganaste el chance.");
                Console.WriteLine("Ganancia: $" + apuesta);
            }
            else
            {
                Console.WriteLine("Lo siento, no ganaste.");
                Console.WriteLine("Perdiste: $" + apuesta);
            }

            Console.ReadKey();
        }

        static int GenerarNumeroSorteo()
        {
            Random rnd = new Random();
            return rnd.Next(1000, 10000);


        }
    }
}
