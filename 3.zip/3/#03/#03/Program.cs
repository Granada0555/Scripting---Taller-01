﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /* Escriba una función para determinar si el jugador ganó el sorteo
           El plan de pagos es como sigue:
            $4500 por cada $1 apostado, si el número es acertado con las cuatro cifras en su orden.
            $200 por cada $1 apostado, si el número es acertado con las cuatro cifras en desorden
            $400 por cada $1 apostado, si se aciertan las últimas 3 cifras del número en su orden
            $50 por cada $1 apostado, si se aciertan las últimas 2 cifras del número en su orden
            $5 por cada $1 apostado, si se acierta la última cifra del número.
            Escriba una función para determinar, si el jugador obtuvo algún premio, el valor del mismo.En caso contrario, retornar un 0.*/



            Console.Write("Ingrese el número apostado (4 dígitos): ");
            string numeroApostado = Console.ReadLine();

            Console.Write("Ingrese el número del sorteo (4 dígitos): ");
            string numeroSorteo = Console.ReadLine();

            int apuesta = 1000;

            int premio = CalcularPremio(numeroApostado, numeroSorteo, apuesta);

            if (premio > 0)
            {
                Console.WriteLine("¡Ganaste un premio!");
                Console.WriteLine("Premio: $" + premio);
            }
            else
            {
                Console.WriteLine("No obtuviste ningún premio.");
            }

            Console.ReadKey();
        }

        static int CalcularPremio(string apostado, string sorteo, int apuesta)
        {
            if (apostado == sorteo)
                return apuesta * 4500;

            if (SonMismosNumerosEnDesorden(apostado, sorteo))
                return apuesta * 200;

            if (apostado.Substring(1, 3) == sorteo.Substring(1, 3))
                return apuesta * 400;

            if (apostado.Substring(2, 2) == sorteo.Substring(2, 2))
                return apuesta * 50;

            if (apostado.Substring(3, 1) == sorteo.Substring(3, 1))
                return apuesta * 5;

            return 0;
        }

        static bool SonMismosNumerosEnDesorden(string a, string b)
        {
            char[] arrA = a.ToCharArray();
            char[] arrB = b.ToCharArray();

            Array.Sort(arrA);
            Array.Sort(arrB);

            return new string(arrA) == new string(arrB);
        }


    }
    }

