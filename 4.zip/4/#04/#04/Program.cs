﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.Write("Ingrese una palabra o frase: ");
            string mensaje = Console.ReadLine();

            AbstractSample obj1 = new MensajeNormal();
            AbstractSample obj2 = new MensajeInvertido();

            Console.WriteLine("\n--- Mensaje Normal ---");
            obj1.PrintMessage(mensaje);
            Console.WriteLine("Invertido: " + obj1.InvertMessage(mensaje));

            Console.WriteLine("\n--- Mensaje con Mayúsculas y Minúsculas Invertidas ---");
            obj2.PrintMessage(mensaje);
            Console.WriteLine("Invertido: " + obj2.InvertMessage(mensaje));

            Console.ReadKey();
        }
    }

    abstract class AbstractSample
    {
        private string message;

        public abstract void PrintMessage(string mensaje);

        public virtual string InvertMessage(string mensaje)
        {
            message = mensaje;
            char[] letras = message.ToCharArray();
            Array.Reverse(letras);
            return new string(letras);
        }
    }

    class MensajeNormal : AbstractSample
    {
        public override void PrintMessage(string mensaje)
        {
            Console.WriteLine(mensaje);
        }
    }

    class MensajeInvertido : AbstractSample
    {
        public override void PrintMessage(string mensaje)
        {
            Console.WriteLine(CambiarMayusculasMinusculas(mensaje));
        }

        public override string InvertMessage(string mensaje)
        {
            string invertido = base.InvertMessage(mensaje);
            return CambiarMayusculasMinusculas(invertido);
        }

        private string CambiarMayusculasMinusculas(string texto)
        {
            char[] letras = texto.ToCharArray();

            for (int i = 0; i < letras.Length; i++)
            {
                if (char.IsUpper(letras[i]))
                    letras[i] = char.ToLower(letras[i]);
                else if (char.IsLower(letras[i]))
                    letras[i] = char.ToUpper(letras[i]);
            }

            return new string(letras);
        }
    }


}
    

