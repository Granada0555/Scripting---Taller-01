﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Ingrese una palabra o frase: ");
            string mensaje = Console.ReadLine();

            MessageManager manager = new MessageManager();
            manager.MostrarMensajes(mensaje);

            Console.ReadKey();
        }
    }

    // ===== Clase abstracta =====
    abstract class AbstractSample
    {
        public abstract void PrintMessage(string mensaje);
    }

    // ===== Primera subclase =====
    class MensajeNormal : AbstractSample
    {
        public override void PrintMessage(string mensaje)
        {
            Console.WriteLine(mensaje);
        }
    }

    // ===== Segunda subclase =====
    class MensajeInvertido : AbstractSample
    {
        public override void PrintMessage(string mensaje)
        {
            Console.WriteLine(CambiarMayusculasMinusculas(mensaje));
        }

        private string CambiarMayusculasMinusculas(string texto)
        {
            char[] letras = texto.ToCharArray();

            for (int i = 0; i < letras.Length; i++)
            {
                if (char.IsUpper(letras[i]))
                    letras[i] = char.ToLower(letras[i]);
                else if (char.IsLower(letras[i]))
                    letras[i] = char.ToUpper(letras[i]);
            }

            return new string(letras);
        }
    }

    // ===== Clase solicitada en el último punto =====
    class MessageManager
    {
        private AbstractSample mensaje1;
        private AbstractSample mensaje2;

        public MessageManager()
        {
            mensaje1 = new MensajeNormal();
            mensaje2 = new MensajeInvertido();
        }

        public void MostrarMensajes(string texto)
        {
            Console.WriteLine("\n--- Mensaje Normal ---");
            mensaje1.PrintMessage(texto);

            Console.WriteLine("\n--- Mensaje con Mayúsculas y Minúsculas Invertidas ---");
            mensaje2.PrintMessage(texto);
        
        }
    }
    }

